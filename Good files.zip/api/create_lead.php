<?php
declare(strict_types=1);

require_once __DIR__ . '/../require_login.php';
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../db.php';

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) $input = [];

$first = trim((string)($input['first_name'] ?? ''));
$last  = trim((string)($input['last_name'] ?? ''));
$email = trim((string)($input['email'] ?? ''));
$phone = trim((string)($input['phone'] ?? ''));
$location = trim((string)($input['location'] ?? ''));
$source = trim((string)($input['source'] ?? ''));
$notes = trim((string)($input['notes'] ?? ''));
$status = trim((string)($input['status'] ?? 'New'));
$bucket = trim((string)($input['bucket'] ?? 'New Lead'));
$follow_up = trim((string)($input['follow_up'] ?? ''));

try {
    $stmt = $pdo->prepare("
        INSERT INTO leads
        (first_name, last_name, email, phone, location, source, notes, status, bucket, follow_up)
        VALUES
        (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    $stmt->execute([$first, $last, $email, $phone, $location, $source, $notes, $status, $bucket, ($follow_up === '' ? null : $follow_up)]);

    echo json_encode([
        "status" => "success",
        "id" => (int)$pdo->lastInsertId()
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => $e->getMessage()
    ]);
}