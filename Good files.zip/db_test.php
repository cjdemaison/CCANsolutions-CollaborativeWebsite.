<?php
require 'db.php';
echo "CONNECTED";