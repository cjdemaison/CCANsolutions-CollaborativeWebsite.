<?php require __DIR__ . '/require_login.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CCAN Solutions About Us Page</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <h1>About Us, The CCAN Solutions Team!</h1>
  <p>This page features everything you might need or want to know about us and who we are.</p>

</body>
</html>
